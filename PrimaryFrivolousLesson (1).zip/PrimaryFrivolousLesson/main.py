import os
from telegram.ext import Application
from handlers import start, prediction, auto_predictions
from utils.database import init_db
from apscheduler.schedulers.asyncio import AsyncIOScheduler

TELEGRAM_TOKEN = os.environ['TELEGRAM_TOKEN']

async def post_init(app):
    await init_db()
    scheduler = AsyncIOScheduler()
    scheduler.add_job(auto_predictions.send_daily_predictions, 'cron', hour=9, args=[app])
    scheduler.start()

if __name__ == "__main__":
    app = Application.builder().token(TELEGRAM_TOKEN).post_init(post_init).build()

    app.add_handler(start.start_handler)
    app.add_handler(prediction.prediction_handler)

    app.run_polling()