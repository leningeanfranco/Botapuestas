import pandas as pd
from sklearn.ensemble import RandomForestClassifier

def train_goal_model():
    # Datos de ejemplo (reemplazar con scraping real)
    data = pd.DataFrame({
        'home_goals_avg': [1.8, 1.2, 2.1],
        'away_goals_avg': [0.9, 1.5, 1.3],
        'btts_last_5': [3, 4, 2],
        'over_2.5': [1, 0, 1]  # 1=True, 0=False
    })

    model = RandomForestClassifier()
    model.fit(data[['home_goals_avg', 'away_goals_avg', 'btts_last_5']], data['over_2.5'])
    return model