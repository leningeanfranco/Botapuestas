import os
import requests

def obtener_prediccion(equipo_local, equipo_visitante):
    API_KEY = os.environ["API_FOOTBALL_KEY"]
    url = "https://v3.football.api-sports.io/predictions"

    headers = {
        "x-apisports-key": API_KEY
    }

    params = {
        "h2h": f"{equipo_local}-{equipo_visitante}"
    }

    response = requests.get(url, headers=headers, params=params)
    return response.json()
