from bs4 import BeautifulSoup
import requests
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager

def scrape_fbref(team1, team2):
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)

    try:
        driver.get(f"https://fbref.com/en/search/search.fcgi?search={team1}+{team2}")
        soup = BeautifulSoup(driver.page_source, 'html.parser')

        # Extraer datos clave
        last_match = soup.select_one('.stats_table tbody tr')
        date = last_match.select_one('[data-stat="date"]').text
        score = last_match.select_one('[data-stat="score"]').text

        return {
            "last_match_date": date,
            "last_score": score,
            "stats": {
                "xG": last_match.select_one('[data-stat="xg"]').text,
                "shots": last_match.select_one('[data-stat="sh"]').text
            }
        }
    finally:
        driver.quit()