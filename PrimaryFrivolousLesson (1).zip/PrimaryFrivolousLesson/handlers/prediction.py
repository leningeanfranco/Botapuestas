from telegram import Update
from telegram.ext import ContextTypes, CommandHandler
from utils import api_football, scrapers, ml_models

async def prediction_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    teams = context.args
    if len(teams) < 2:
        await update.message.reply_text("⚠️ Usa: /prediccion <equipo1> <equipo2>")
        return

    team1, team2 = teams[0], teams[1]

    # 1. Buscar en API Football
    match_data = await api_football.get_match(team1, team2)

    if not match_data:
        # 2. Si no hay partido, buscar histórico con scraping
        await update.message.reply_text("🔍 Buscando datos históricos...")
        scraped_data = scrapers.scrape_fbref(team1, team2)
        response = f"⚽ Último enfrentamiento ({scraped_data['last_match_date']}):\n"
        response += f"Resultado: {scraped_data['last_score']}\n"
        response += f"xG: {scraped_data['stats']['xG']} | Tiros: {scraped_data['stats']['shots']}"

    else:
        # 3. Predecir con ML si hay partido próximo
        model = ml_models.train_goal_model()
        prediction = model.predict([[match_data['home_avg'], match_data['away_avg'], match_data['btts']]])
        tip = "OVER 2.5 ✅" if prediction[0] == 1 else "UNDER 2.5 ⚠️"

        response = f"🔮 Predicción para {team1} vs {team2}:\n"
        response += f"📅 {match_data['date']}\n"
        response += f"💡 Recomendación: {tip}"

    await update.message.reply_text(response)

prediction_handler = CommandHandler('prediccion', prediction_handler)