# handlers/auto_predictions.py
from telegram.ext import ContextTypes

async def send_daily_predictions(app):
    chat_id = "@tucanal"  # Cambia esto por tu canal o chat ID
    await app.bot.send_message(chat_id=chat_id, text="🔮 Predicciones diarias activadas!")
